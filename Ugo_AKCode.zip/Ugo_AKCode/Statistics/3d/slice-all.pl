#!/usr/bin/perl -w

$start = $ARGV[0];
$end = $ARGV[1];

for ($i=$start;$i<=$end; $i++) {

    $filename = sprintf("snapshot_%04d.h5",$i);
    $ofile = sprintf("%04d.plt",$i);

    $command_line = sprintf("~/working/new-statistics/tecplot/hdf5-slice-2d x 20 %s tmp.plt",$filename);
    system $command_line;
    $command_line = sprintf("/usr/local/tecplot10/bin/preplot -b tmp.plt %s",$ofile);
    system $command_line;

}
