#!/usr/bin/perl -w

$start = $ARGV[0];
$end = $ARGV[1];
$step = $ARGV[2];

for ($i=$start;$i<=$end; $i=$i+$step)  {

    $filename = sprintf("snapshot_%04d.h5",$i);
    
    $command_line = sprintf("/storage/home/izn20/Ugo_AKCode/les3d-mpp/hdf5-tools/hdf5-join %s",$filename);
    system $command_line;

}
