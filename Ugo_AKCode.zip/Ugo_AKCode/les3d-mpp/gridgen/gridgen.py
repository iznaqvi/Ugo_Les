#!/usr/bin/python
# gridgen.py - Simple Python script for generating a grid
# Copyright (c) 2004 Tony Keating <akeating@eng.umd.edu>
#
# Usage: ./gridgen.py ni "equation"
#
# Equation can be any python statement, where x is the uniform grid between 0,1
# ie. for the channel flow with tanh stretching,
# ./gridgen.py 65 "tanh(2.2*(2.0*(x-0.5)))/tanh(2.2)+1"
# or for a uniform grid with length 2*pi
# ./gridgen.py 48 "2*pi*x"

import sys
from math import *

# Grab the grid information from the command line
n = int(sys.argv[1])
eqn = sys.argv[2]

# Generate a uniform mesh [0,1]
x_uni = []
for i in range(n+1):
    x_uni.append((i)*(1.0)/(n))

# Transform the mesh using the transform function
grid_x = []
for i in range(n+1):
    x = x_uni[i]
    grid_x.append(eval(eqn))

# Output the grid 
print n
for i in range(n+1):
    print "%20.10e" % grid_x[i]
