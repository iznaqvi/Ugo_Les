#!/usr/bin/python
# gridgen2.py - Smoothed non-uniform grid generator
# Copyright (c) 2004 Tony Keating <akeating@eng.umd.edu>

import sys
from math import *

# control points

# Warnack and Fernholz accelerating boundary layer case
# Total cells = 384
#cp_x = [ 2.2, 1.0, 1.6 ]
#cp_n = [ 148, 172, 64 ]

#cp_x = [ 2.5, 1.8, 10.0 ] 
#cp_n = [ 160, 90, 6 ]        

#cp_x = [ 0.04, 0.01125, 0.04 ]
#cp_n = [ 16, 64, 16 ]

cp_x = [ 0.5, 0.05, 0.4 ]
cp_n = [ 19, 16, 37 ]

smooth = 100

grid_x = []
x = 0.0
grid_x.append(x)

for n in range(len(cp_x)):
    for i in range(cp_n[n]):
        x = x + cp_x[n]
        grid_x.append(x)

xf = grid_x

for n in range(smooth-1):
    for ii in range(len(grid_x)-2):
        i = ii + 1
        xf[i] = 0.25 * grid_x[i-1] + 0.5 * grid_x[i] + 0.25 * grid_x[i+1]
    grid_x = xf

print "number of cells: %i" % (len(grid_x)-1)
print "length of domain: %f" % (grid_x[len(grid_x)-1])

f = open("grid","w")
f.write("%i \n" % ( len(grid_x)-1) )
for i in range(len(grid_x)):
    f.write("%20.10e\n" % grid_x[i])
f.close()

f = open("grid.dx","w")
for i in range(len(grid_x)-1):
    f.write("%f %f\n" % ( grid_x[i],grid_x[i+1] - grid_x[i] ))
f.close()

    

