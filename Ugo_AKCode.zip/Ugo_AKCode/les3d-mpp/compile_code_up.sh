# gedit array_sizes.h % change ghostcell
# gedit test.sh % change number of processors

# compile on my hpcvl account

## Prima di tutto edita la griglia, il Reynolds e gli altri parametri
## ovvero: apriti /config/XXX.config

## Edita ora anche il file les3d-mp.par (parametri letti al runtime)

## Per cambiare la dimensione dello stack: ulimit -s unlimited  (-a per vedere i limiti attuali). 
## Il manuale sta nel manuale di bash. Digita man bash e poi '/' per cercare ulimit.


## EXPLICIT FILTERING
cd /home/hpc2073/AKCode/les3d-mpp;
setenv DDIR blayer_les_up_768_80_64; 
make clean; setup.py $DDIR; make les=false mpi=true;
setenv PPATH /updata/data1/iftekhar/AKCodeRun/$DDIR;
mkdir $PPATH; mkdir $PPATH/snap; mkdir $PPATH/restart; cp input* $PPATH;
cp les3d-mp $PPATH; cp problem_def.h $PPATH; cp configs/$DDIR.config $PPATH; 
cp array_sizes.h $PPATH;cp configs/blayer/inflow.dat $PPATH/inflow.dat;
cp configs/blayer/inflow.target $PPATH/inflow.target;cp configs/blayer/blayer.dat $PPATH/blayer.dat; 
cp plotscript $PPATH; cp les3d-mp.par $PPATH; cd $PPATH


## lancia il codice dalla directory di run in cui ci siamo appena spostati

./les3d-mp >STD.out &
tail -f STD.out

#qsub np_16.sh

## monitora il lancio con gnuplot: plot "history" u 1:4 w l
## oppure usa il file plotscript che hai copiato nella cartella di run: load 'plotscript'

## Per fermare il codice 
touch STOP_NOW
mv restart.h5 restart/
rm STOP_NOW

# Postprocessing
# Capisci quale e` il tempo che ti interessa con
#  h5dump -d elapsed\ simulation\ time snapshot_0080.h5

cd /home/valerio/AKCode/Statistics/1d; make clean; make all
cd $PPATH/snap
 /home/valerio/AKCode/Statistics/1d/statistics 4100 4110 1
