# gedit array_sizes.h % change ghostcell
# gedit test.sh % change number of processors

gmake clean; setup.py channel_DNS; gmake les=false mpi=true; export PPATH=/u1/work/hpc2133/Channel/Reb5000_256x192x256_DNS_nproc8; mv input* $PPATH; mv les3d-mp $PPATH; mv problem_def.h $PPATH; cp configs/channel_DNS.config $PPATH; cp les3d-mp.par $PPATH;

Reb5000_256x192x256_DNS_nproc1
Reb5000_256x192x256_DNS_nproc4
Reb5000_256x192x256_DNS_nproc8
