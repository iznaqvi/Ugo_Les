  integer, parameter :: ni = 1200
  integer, parameter :: nj = 280
  integer, parameter :: nk = 360
  integer, parameter :: rescaling_niter = 1000
  integer, parameter :: rescaling_iplane = 700
  integer, parameter :: initial_conditions_noise_jmax = 180
  real, parameter :: initial_conditions_noise = 0.3
  real, parameter :: dstar_in_ref = 1
  real, parameter :: rescaling_Tavg = 200.0
  logical, parameter :: bottom_wlm = .false.
  character(len=12), parameter :: initial_inputfile = "inflow.dat"
  real :: Re = 7500.0
