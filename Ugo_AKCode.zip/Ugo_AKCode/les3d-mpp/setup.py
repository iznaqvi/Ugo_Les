#!/usr/bin/python
# setup.py for les3d-mp
# Copyright (c) 2004 Tony Keating <akeating@eng.umd.edu>
#
# Reads and parses the problem setup configuration file in setups/
# Creates three grid files, input.gridx, input.gridy, input.gridz.
# Creates a Fortran 90 module, problem_def.90
# Creates a set of Makefile definitions, problem_def.make

# Read and process the user hooks in les3d-mp.f90
# Write the new main driver as les3d-mp-processed.f90

import os
import sys
import string

def chomp(lines):
    "Remove the end of line markers from an array of strings"
    for i in range(len(lines)):
        if lines[i][-1] == '\n':
            lines[i] = lines[i][:-1]

print "Parsing configuration file: configs/%s.config" % sys.argv[1]
cfgfile = open('configs/%s.config' % sys.argv[1],'r')

cfg = []
integers = {}
reals = {}
logicals = {}
cintegers = {}
creals = {}
clogicals = {}
cstrings = {}
options = {}
includes = []
f77includes = []
lesincludes = []
cppflags = []
userhooks = []
for s in cfgfile.readlines():
    if s[0] <> "#": # ignore comments
        sp = s.split()
        if len(sp) > 0:
            if sp[0] == 'VARIABLE':
                if sp[1] == 'integer':
                    integers[sp[2]] = string.join(sp[3:])
                elif sp[1] == 'real':
                    reals[sp[2]] = sp[3]
                elif sp[1] == 'logical':
                    logicals[sp[2]] = sp[3]
            elif sp[0] == 'CONSTANT':
                if sp[1] == 'integer':
                    cintegers[sp[2]] = sp[3]
                elif sp[1] == 'real':
                    creals[sp[2]] = sp[3]
                elif sp[1] == 'logical':
                    clogicals[sp[2]] = sp[3]
                elif sp[1] == 'string':
                    cstrings[sp[2]] = string.join(sp[3:])
            elif sp[0] == 'OPTION':
                options[sp[1]] = string.join(sp[2:])
            elif sp[0] == 'INCLUDE':
                includes.append(sp[1])
            elif sp[0] == 'F77INCLUDE':
                f77includes.append(sp[1])
            elif sp[0] == 'LES_INCLUDE':
                lesincludes.append(sp[1])
            elif sp[0] == 'CPPFLAGS':
                cppflags.append(sp[1])
            elif sp[0] == 'USER_HOOK':
                userhooks.append(sp[1])

#print integers
#print reals
#print logicals
#print includes

# Create the grid 

if options['ni'] == "EXTERNAL": 
    os.popen('cp %s input.gridx' %
             (options['gridx']))
    f = open("input.gridx","r")
    options['ni'] = f.readline().strip()
    f.close()
else:
    os.popen('./gridgen/gridgen.py %s "%s" > input.gridx' %
             (options['ni'],options['gridx']))

if options['nj'] == "EXTERNAL": 
    os.popen('cp %s input.gridy' %
             (options['gridy']))
    f = open("input.gridy","r")
    options['nj'] = f.readline().strip()
    f.close()
else:
    os.popen('./gridgen/gridgen.py %s "%s" > input.gridy' %
             (options['nj'],options['gridy']))
    
os.popen('./gridgen/gridgen.py %s "%s" > input.gridz' %
         (options['nk'],options['gridz']))

# Put all the variables into the problem_def.h

ffile = open('problem_def.h','w+')
ffile.write("  integer, parameter :: ni = %s\n" % (options['ni']) )
ffile.write("  integer, parameter :: nj = %s\n" % (options['nj']) )
ffile.write("  integer, parameter :: nk = %s\n" % (options['nk']) )

for var in cintegers.keys():
    ffile.write("  integer, parameter :: %s = %s\n" % (var,cintegers[var]) )
for var in creals.keys():
    ffile.write("  real, parameter :: %s = %s\n" %
                (var,creals[var]) )
for var in clogicals.keys():
    ffile.write("  logical, parameter :: %s = .%s.\n" % (var,clogicals[var]) )
for var in cstrings.keys():
    ffile.write("  character(len=%s), parameter :: %s = %s\n" % (len(cstrings[var]),var,cstrings[var]) )

for var in integers.keys():
    ffile.write("  integer :: %s = %s\n" % (var,integers[var]) )
for var in reals.keys():
    ffile.write("  real :: %s = %s\n" %
                (var,reals[var]) )
for var in logicals.keys():
    ffile.write("  logical :: %s = .%s.\n" % (var,logicals[var]) )

ffile.close()

# Write the Makefile definitions, problem_def.make

mfile = open('problem_def.make','w+')
if len(cppflags) > 0:
    mfile.write("flags += ")
    for s in cppflags:
        mfile.write("-D%s " % s)
    mfile.write("\n\n")

if len(includes) > 0:
    mfile.write("srcs += ")
    for s in includes:
        mfile.write("\\\n%s " % s)
    mfile.write("\n\n")

if len(f77includes) > 0:
    mfile.write("f77srcs += ")
    for s in f77includes:
        mfile.write("\\\n%s " % s)
    mfile.write("\n\n")

if len(lesincludes) > 0:
    mfile.write("lessrcs += ")
    for s in lesincludes:
        mfile.write("\\\n%s " % s)
    mfile.write("\n")

mfile.close()
cfgfile.close()

# Process the user hooks

hsrcs = []
hmodules = []
hinit = []
hfin = []
hread = []
hwrite = []
hafterpred = []
hafterts = []

for s in userhooks:
    print "Adding in user hook: %s" % s
    hfile = open('user_hooks/%s.hook' % s,'r')
    for s in hfile.readlines():
        if s[0] <> "#": # ignore comments
            sp = s.split()
            if len(sp) > 0:
                if sp[0] == 'SOURCE':
                    hsrcs.append(sp[1])
                elif sp[0] == 'MODULE':
                    hmodules.append(sp[1])
                elif sp[0] == 'INITIALIZE':
                    hinit.append(sp[1])
                elif sp[0] == 'FINALIZE':
                    hfin.append(sp[1])
                elif sp[0] == 'READ_DATA':
                    hread.append(sp[1])
                elif sp[0] == 'WRITE_DATA':
                    hwrite.append(sp[1])
                elif sp[0] == 'AFTER_PREDICTOR':
                    hafterpred.append(sp[1])
                elif sp[0] == 'AFTER_TIMESTEP':
                    hafterts.append(sp[1])
                    
    hfile.close()

mfile = open('problem_def.make','a')
if len(hsrcs) > 0:
    mfile.write("srcs += ")
    for s in hsrcs:
        mfile.write("\\\nuser_hooks/%s " % s)
    mfile.write("\n")
mfile.close()

iffile = open('les3d-mp.f90','r')
offile = open('les3d-mp-processed.f90','w+')
for s in iffile.readlines():
    sp = s.split()
    if len(sp) > 0:
        if sp[0] == '@user_hook':
            if sp[1] == 'modules':
                for t in hmodules:
                    offile.write("  use %s\n" % t)
            if sp[1] == 'initialize':
                for t in hinit:
                    offile.write("  call %s\n" % t)
            if sp[1] == 'finalize':
                for t in hfin:
                    offile.write("  call %s\n" % t)
            if sp[1] == 'write_data':
                for t in hwrite:
                    offile.write("  call %s\n" % t)
            if sp[1] == 'read_data':
                for t in hread:
                    offile.write("  call %s\n" % t)
            if sp[1] == 'after_predictor':
                for t in hafterpred:
                    offile.write("  call %s\n" % t)
            if sp[1] == 'after_timestep':
                for t in hafterts:
                    offile.write("  call %s\n" % t)
        else:
            offile.write(s)
    else:
        offile.write(s)
        
iffile.close()
offile.close()

print "Created new main program with user hooks included"





