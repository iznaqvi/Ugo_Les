#!/usr/bin/perl
# Based on the original makemake.pl by Michael Wester <wester@math.unm.edu>
# Modified for autogenerating make by Tony Keating <keating@mech.uq.edu.au>

&MakeDependsf90($ARGV[1]);

sub PrintWords {
   local($columns) = 78 - shift(@_);
   local($extratab) = shift(@_);
   local($wordlength);
   #
   print  @_[0];
   $columns -= length(shift(@_));
   foreach $word (@_) {
      $wordlength = length($word);
      if ($wordlength + 1 < $columns) {
         print  " $word";
         $columns -= $wordlength + 1;
         }
      else {
         #
         # Continue onto a new line
         #
         if ($extratab) {
            print   " \\\n\t\t$word";
            $columns = 62 - $wordlength;
            }
         else {
            print   " \\\n\t$word";
            $columns = 70 - $wordlength;
            }
         }
      }
   }

sub toLower {
   local($string) = @_[0];
   $string =~ tr/A-Z/a-z/;
   $string;
   }

sub uniq {
   local(@words);
   foreach $word (@_) {
      if ($word ne $words[$#words]) {
         push(@words, $word);
         }
      }
   @words;
   }

sub trim {
    for (@_) {
        s/^\s*//; # trim leading spaces
        s/\s*$//; # trim trailing spaces
    }
    return @_;
}

sub MakeDependsf90 {
   local($compiler) = &toLower(@_[0]);
   local(@dependencies);
   local(%filename);
   local(@incs);
   local(@modules);
   local(@incs2);
   local($objfile);
   
#   foreach $file (<*.f90>) {
   foreach $file (@ARGV) {
       open(FILE, $file) || warn "Cannot open $file: $!\n";
       while (<FILE>) {
	   chomp;
           /^\s*module\s+([^"]+)/i && 
	       ($filename{&toLower($1)} = $file) =~ s/\.f90$/.o/;
       }
   }

   $file = $ARGV[0];
   open(FILE, $file) || warn "Cannot open $file: $!\n";
   while (<FILE>) {
       chomp;
       /^\s*include\s+["\']([^"\']+)["\']/i && push(@incs, $1);
       /^\s*\#include\s+["\']([^"\']+)["\']/i && push(@incs, $1);
       /^\s*use\s+([^"]+)/i && push(@modules, &toLower($1));
   }

   # remove the include files that don't exist

   foreach $incfile (@incs) {
       if (-e $incfile) {
	   push(@incs2,$incfile);
       }
   }

   if (defined @incs || defined @modules) {
         ($objfile = $file) =~ s/\.f90$/.o/;
	 ($depfile = $file) =~ s/\.f90$/.dep/;
         print  "$objfile: $file ";
         undef @dependencies;
         foreach $module (@modules) {
	     # nasty trick to split the module name from , only => crap
	     @blah = split(/,/,$module);
	     $module = @blah[0];
	     trim($module);
#	     print "looking for -",$module,"-\n";
#	     print "found in file -",$filename{$module},"-\n";
            push(@dependencies, $filename{$module});
            }
         @dependencies = &uniq(sort(@dependencies));
         &PrintWords(length($objfile) + 2, 0,
                     @dependencies, &uniq(sort(@incs2)));
         print  "\n";
         undef @incs;
	 undef @incs2;
         undef @modules;
         }
      
   }
