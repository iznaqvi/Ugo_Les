clc;
clear all;
format long;
fid = fopen('BL_UProfile.dat','r');
a=fscanf(fid, '%g %g\n',[2 inf]);
a=a';
fclose(fid);
y=a(:,1);
u=a(:,2);
momth=0.0;
disth=0.0;
n=length(u);
for i=1:n-1
disth=disth+(y(i+1)-y(i))*0.5*((1-u(i)/u(n))+(1-u(i+1)/u(n)));
end
disth
Re=19.2024*u(n)*disth/1.568e-5
fid = fopen('Slot_UProfile23.dat','r');
a23=fscanf(fid, '%g %g\n',[2 inf]);
a23=a23';
fclose(fid);
ys23=a23(:,1);
u23=a23(:,2);
ubulk23=0.0;
area23=0.0;
n23=length(u23);
for j=1:n23-1
    ubulk23=ubulk23+0.5*(ys23(j+1)-ys23(j))*(u23(j)+u23(j+1));
    area23=area23+(ys23(j+1)-ys23(j));
end
ubulk23=ubulk23/area23
u23=u23.*2.3/ubulk23;
ubulk23=0.0;
area23=0.0;
n23=length(u23);
for j=1:n23-1
    ubulk23=ubulk23+0.5*(ys23(j+1)-ys23(j))*(u23(j)+u23(j+1));
    area23=area23+(ys23(j+1)-ys23(j));
end
ubulk23=ubulk23/area23

figure(1);
plot(ys23,u23);

figure(2);
fid = fopen('Slot_UProfile75b.dat','r');
a7=fscanf(fid, '%g %g\n',[2 inf]);
a7=a7';
fclose(fid);
ys7=a7(:,1);
u7=a7(:,2);
ubulk7=0.0;
area7=0.0;
n7=length(u7);
for j=1:n7-1
    ubulk7=ubulk7+0.5*(ys7(j+1)-ys7(j))*(u7(j)+u7(j+1));
    area7=area7+(ys7(j+1)-ys7(j));
end
ubulk7=ubulk7/area7
u7=u7.*.75/ubulk7;
ubulk7=0.0;
area7=0.0;
n7=length(u7);
for j=1:n7-1
    ubulk7=ubulk7+0.5*(ys7(j+1)-ys7(j))*(u7(j)+u7(j+1));
    area7=area7+(ys7(j+1)-ys7(j));
end
ubulk7=ubulk7/area7
plot(ys7,u7);
fid=fopen('Uprof_BL_sc.dat','w');
for j=1:n
    fprintf(fid,'%16.10f %16.10f \n',y(j)/disth,u(j));
end
fid=fopen('Uprof_Slot23.dat','w');
for j=1:n23
    fprintf(fid,'%16.10f %16.10f \n',ys23(j)/disth,u23(j));
end
fid=fopen('Uprof_Slot75.dat','w');
for j=1:n7
    fprintf(fid,'%16.10f %16.10f \n',ys7(j)/disth,u7(j));
end
    