clc;
clear all;
format long;
dx=0.065;
x(1)=0.0;
for i=2:40
    x(i)=x(i-1)+dx;
end
x(40);
n=length(x);
str=1.03373;
for i=1:75
    x(n+i)=x(n+i-1)+dx*str^(i-1);
end
n=length(x);
n;
x(n);
dx=x(n)-x(n-1);
for i=n+1:513
    x(i)=x(i-1)+dx;
end
x(513);
fid=fopen('Grid_X.dat','w');
fprintf(fid,'%12.6f \n',x');
fclose(fid);
fid=fopen('DiffGrid_X.dat','w');
fprintf(fid,'%12.6f \n',(diff(x))');
fclose(fid);
%
YU=load('Uprof_Slot23.dat');
ys=YU(:,1);
us=YU(:,2);
BLU=load('Uprof_BL_sc.dat');
ybl=BLU(:,1);
ubl=BLU(:,2);
disth=0.0;
nbl=length(ubl);
for i=1:nbl-1
disth=disth+(ybl(i+1)-ybl(i))*0.5*((1-ubl(i)/ubl(nbl))+(1-ubl(i+1)/ubl(nbl)));
end
disth
% ubl(nbl)
nys=length(ys);
% us=us./ubl(nbl);
uobulk=0.0;
areao=0.0;
for j=1:nbl-1
uobulk=uobulk+0.5*(ubl(j)+ubl(j+1))*(ybl(j+1)-ybl(j));
areao=areao+(ybl(j+1)-ybl(j));
end
uobulk=uobulk/areao
usbulk=0.0;
areas=0.0;
for j=1:nys-1
usbulk=usbulk+0.5*(us(j)+us(j+1))*(ys(j+1)-ys(j));
areas=areas+(ys(j+1)-ys(j));
end
usbulk=usbulk/areas
ys(nys)
return
% us=2.3*us./usbulk;
% ys=ys./disth;
% ybl=ybl./disth;
% ubl=ubl./ubl(nbl);
fid=fopen('Uprof_whitelaw_96.dat','w');
fprintf(fid,'%12.6f \n',ybl');
fclose(fid);
%
str2=4.1663376;
n=60;
h=ys(nys);
for j=1:n
    eta=double(j-1)/double(n-1);
    f1=0.5*(1.0+tanh(str2*(eta-0.5))/tanh(str2*0.5));
    y(j)=f1*h;
    y1(j)=y(j);
end
% y(2)-y(1)
% y(n)-y(n-1)
% y(1)
% y(n)
for j=1:n-1
    y4(j)=0.5*(y1(j)+y1(j+1));
end
fid=fopen('Grid_Ys.dat','w');
fprintf(fid,'%20.12f \n',y4');
fclose(fid);
str2=3.290378133;
n=17;
h=0.126*ys(nys);
for j=1:n
    eta=double(j-1)/double(n-1);
    f1=0.5*(1.0+tanh(str2*(eta-0.5))/tanh(str2*0.5));
    y2(j)=f1*h;
end
% y2(2)-y2(1)
% y2(n)-y2(n-1)
% y2(1)
% y2(n)
str2=3.7230321315;
n=80;
h=65;
for j=1:n
    eta=double(j-1)/double(n-1);
    f1=0.5*(1.0-tanh(str2*(1-eta))/tanh(str2));
    y3(j)=2*f1*h;
end
% y3(2)-y3(1)
% y3(n)-y3(n-1)
% y3(1)
% y3(n)
for j=1:n-1
    y5(j)=0.5*(y3(j)+y3(j+1));
end
fid=fopen('Grid_Ybs.dat','w');
fprintf(fid,'%20.12f \n',y5');
fclose(fid);
n=length(y);
n1=length(y2);
for j=1:n1-1
    y(n+j)=y(n)+y2(j+1);
end
n=length(y);
n1=length(y3);
for j=1:n1-1
    y(n+j)=y(n)+y3(j+1);
end
n=length(y);
fid=fopen('Grid_Y.dat','w');
fprintf(fid,'%20.12f \n',y');
fclose(fid);
fid=fopen('DiffGrid_Y.dat','w');
fprintf(fid,'%12.6f \n',(diff(y))');
fclose(fid);

us1=spline(ys,us,y4);
fid=fopen('Uprofile_slot.dat','w');
fprintf(fid,'%20.12f \n',us1');
fclose(fid);
BL=load('UProfile_Re2400.dat');
yb=BL(:,1);
ub=BL(:,2);
ub1=spline(yb,ub,y5);

fid=fopen('Uprof_Re2400_96.dat','w');
fprintf(fid,'%12.6f \n',(ub(2:97))');
fclose(fid);

n=length(us1);
for j=1:n
    u(j)=us1(j);
end
n=length(u);
n1=length(y2);
for j=1:n1-1
    u(n+j)=0.0;
end
n=length(u);
n1=length(y3);
for j=1:n1-1
    u(n+j)=ub1(j);
end

fid=fopen('U_profOriginal.dat','w');
fprintf(fid,'%12.6f \n',u');
fclose(fid);

ubulk=0.0;
area=0.0;
ny=length(u);
for j=1:ny-1
ubulk=ubulk+0.5*(u(j)+u(j+1))*(y(j+1)-y(j));
area=area+(y(j+1)-y(j));
end
ubulk=ubulk/area

uinlet=spline(yb,ub,y);

fid=fopen('U_prof01b.dat','w');
fprintf(fid,'%12.6f \n',uinlet');
fclose(fid);

lz=28.0;
nz=65;
for k=1:nz
    z(k)=(k-1)*lz/(nz-1);
end
for k=1:nz-1
    z1(k)=0.5*(z(k)+z(k+1));
end
fid=fopen('Grid_Z.dat','w');
fprintf(fid,'%20.12f \n',z1');
fclose(fid);

nbl=length(ybl);
n5=length(y5);

for j=1:n5
    for j1=1:nbl
        if y5(j)> ybl(nbl)
            u5(j)=1.0;
        elseif y5(j) >= ybl(j1) && y5(j) <= ybl(j1+1)
            u5(j)=ubl(j1+1)-(ubl(j1+1)-ubl(j1))*(ybl(j1+1)-y5(j))/(ybl(j1+1)-ybl(j1));
        end
    end
end
%whitelaw profile scaled to boundarylayer at inlet
fid=fopen('U5.dat','w');
% for j=1:n5
% fprintf(fid,'%12.6f %12.6f \n',y5(j),u5(j));
% end
fprintf(fid,'%12.6f \n',u5');
fclose(fid);
fid=fopen('U5_whitelaw.dat','w');
for j=1:n5
fprintf(fid,'%12.6f %12.6f \n',0.0019638*y5(j),u5(j));
end


    

