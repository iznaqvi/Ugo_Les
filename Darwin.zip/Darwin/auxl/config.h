c     ******************************************************************
c     Geometry
c#     define _2DGEOM_ 
c#     define _CARTESIAN_ 
c     ******************************************************************
c     Precison
#    define _DOUBLE_PRECISION_ 
c     *****************************************************************
c     Boundary conditions
#     define _ZPERIODIC_
c#     define _ZFREESLIP_
#    define _TOPFREESLIP_
c#    define _XPERIODIC_
c#    define _XFREESLIP_
c    ********************************************************************
c     QUICK in the potential core
#     define _CENTRALTOQUICK_
c     CENTRAL scheme everywhere
c#    define _CENTRAL_
c     To use QUCIK, do not define CENTRALTOQUICK and CENTRAL 

c    ********************************************************************
c    Scalar transport equation
c#    define _SCALAR1_
c#    define _SCALAR2_
c#    define _SCALAR1_QUICK_
c#    define _SCALAR2_QUICK_
c
c    ********************************************************************
c
c     Wall model
c
c     _RESOLVED_WALL_
c     Fully resolved wall, no approximation
c
c     _SCHUMANN_WALL_
c     Schumann (U. Schumann, 1975) wall approximation
c
#     define _RESOLVED_WALL_
c#     define _SCHUMANN_WALL_
c#     define _3DFLOW_CALC_ 
c#     define _ROUGH_WALL_
c#     define _TLM_

c     ******************************************************************
c
c     _RHIE_AND_CHOW_
c     Use Rhie and Chow scheme (C.M. Rhie and W.L. Chow, 1983)
c     to calculate face fluxes (avoids oscillations)
c
#     define _RHIE_AND_CHOW_
c
c     ******************************************************************
c     Buoyancy
c#     define _BUOYANCY_
c     ******************************************************************
c     Oscillatory flow
c#     define _OSCILLATING_PRESSURE_GRADIENT_
c#     define _BAROCLINIC_PRESSURE_GRADIENT_
c     *******************************************************************
c
c     Inlet boundary
c
c     _RECYCLING_
c     Use recycling
c
c     _RESCALING_
c     Use rescaling (T.S. Lund, X. Wu and K.D. Squires, 1998)
c
c     _SLICE_DATA_
c     Use slice data
c
c#     define _RECYCLING_
c#     define _RESCALING_
#     define _SLICE_DATA_
c
c     ******************************************************************
c
c     Time discretization scheme for the momentum equations
c
c     _ADAMS_BASHFORT_
c     Second-order accurate Adams-Bashfort
c
c     _RK_33_
c     Low-storage Runge-Kutta with three sub-steps (third-order accurate)
c
c     _RK_43_
c     Low-storage Runge-Kutta with four sub-steps
c     (third-order accurate, improved accuracy and stability)
c
c     _RK_54_
c     Low-storage Runge-Kutta with five sub-steps (fourth-order accurate)
c
c     define _CRANK_NICHOLSON_
c     Use Crank-Nicholson for the wall-nomal diffusive terms
c     (ATTENTION: does not work with Schumann wall approximation)
c
#     define _ADAMS_BASHFORT_
c     define _RK_33_
c     define _RK_43_
c     define _RK_54_
#     define _CRANK_NICHOLSON_
c
c     ******************************************************************
c
c     Time discretization scheme for the pressure
c
c     _PRESS_IMP_EULER_
c     Implicit Euler (first-order accurate)
c
c     _PRESS_CRANK_NICHOLSON_
c     Crank-Nicholson (second-order accurate)
c
#     define _PRESS_IMP_EULER_
c     define _PRESS_CRANK_NICHOLSON_
c
c     ******************************************************************
c
c     Subgrid model
c
c     _SMAGORINSKY_
c     Smagorinsky model
c
c     _LAGRANGIAN_DYNAMIC_
c     Lagrangian dynamic model
c
c     _SCALE_SIMILARITY_
c     With scale-similarity stresses
c
c     _DES_
c     Detached-Eddy Simulation
c
c#     define _SMAGORINSKY_
c#     define _SMAG_DAMPING_
c#     define _LAGRANGIAN_DYNAMIC_
c#     define _SCALE_DEPENDENT_
c#     define _SCALE_SIMILARITY_
c#     define _DES_
c#     define _SA_RANS_
c#     define _DDES_
c#     define _IDDES_
c      for LES use Dirichlet in the potential core. 
c#     define _SA_INLET_ROBIN_
c
c#    define _STOCHASTIC_FORCING_ 
c
c     ******************************************************************
c
c     Lagrangian dynamic subgrid model test-filter
c
c     _1D_TEST_FILTER_
c     Test-filter applied in the homogeneous direction only
c
c     _3D_TEST_FILTER_
c     Test-filter applied in all directions
c
c     define _1D_TEST_FILTER_
#     define _3D_TEST_FILTER_
c
c     ******************************************************************
c
c     Iterative improvement of pressure boundary conditions
c
c     Used to set the pressure in a boundary if the boundary-normal
c     direction is not a computational direction
c
c     define _ITER_PRESSURE_BOUND_COND_
c
c     ******************************************************************
c
c     Slice data generation
c
c     _SLICE_GEN_
c     Generate slice data
c
c#     define _SLICE_GEN_
c
c     ******************************************************************
c
c     Linear equation solver for the Poisson equation
c
c     _BICGSTAB_
c     Bi-Conjugate Gradient Stabilised (Bi-CGStab, R. Barrett et al., 1994)
c     solver with Incomplete Choleski (IC) factorization preconditioning
c
c     _IC_
c     Incomplete Choleski (IC) factorization solver
c
c     _SIP_1_ or _SIP_2_
c     Strong Implicit Procedure (SIP) solver (H.L. Stone, 1968)
c
c#     define _BICGSTAB_
c     define _IC_
c#     define _SIP_1_
c#     define _SIP_2_
#     define _FFTK_ 
c#     define _FFTKI_ 
c#    define _PETSC_KSP_
c
c     ******************************************************************
c
c     Momentum and Reynolds-stress budgets
c
c     _BUDGETS_
c     Calculate momentum and Reynolds-stress budgets together with statistics
c
c#     define _BUDGETS_
c
c     ******************************************************************
c
c     Default values for multiple choice options

c     Boundary condition

#     ifndef _ZPERIODIC_
#     ifndef _ZFREESLIP_
#     define _ZPERIODIC_
#     endif
#     endif
c
c     Resolved wall
c
#     ifndef _RESOLVED_WALL_
#     ifndef _SCHUMANN_WALL_
#     ifndef _TLM_
#     define _RESOLVED_WALL_
#     endif
#     endif
#     endif
c
c
c     Inlet boundary
c
#     ifndef _XFREESLIP_
#     ifndef _XPERIODIC_
#     ifndef _RECYCLING_
#     ifndef _RESCALING_
#     ifndef _SLICE_DATA_
#     define _RECYCLING_
#     endif
#     endif
#     endif
#     endif
#     endif
c
c
c     Runge-Kutta with four sub-steps time-discretization scheme
c     for the momentum equations
c
#     ifndef _ADAMS_BASHFORT_
#     ifndef _RK_33_
#     ifndef _RK_43_
#     ifndef _RK_54_
#     define _RK_43_
#     endif
#     endif
#     endif
#     endif
c
c
c     Implicit Euler time-discretization scheme for the pressure

#     ifndef _PRESS_IMP_EULER_
#     ifndef _PRESS_CRANK_NICHOLSON_
#     define _PRESS_IMP_EULER_
#     endif
#     endif
c
c
c     No scale-similarity stresses without the Lagrangian-dynamic model
c
#     ifndef _LAGRANGIAN_DYNAMIC_
#     undef _SCALE_SIMILARITY_
#     endif
c
c
c     Test-filter applied in all directions
c
#     ifdef _LAGRANGIAN_DYNAMIC_
#     ifndef _1D_TEST_FILTER_
#     ifndef _3D_TEST_FILTER_
#     define _3D_TEST_FILTER_
#     endif
#     endif
#     endif
c
#     ifdef _SCALE_DEPENDENT_
#     ifdef _1D_TEST_FILTER_
#     undef _1D_TEST_FILTER_
#     define _3D_TEST_FILTER_
#     endif
#     endif
c
c
c     Strong Implicit Procedure (SIP) solver
c
#     ifndef _BICGSTAB_
#     ifndef _IC_
#     ifndef _SIP_1_
#     ifndef _SIP_2_
#     ifndef _FFTK_
#     ifndef _FFTKI_
#     ifndef _PETSC_KSP_
#     define _SIP_1_
#     endif
#     endif
#     endif 
#     endif
#     endif
#     endif
#     endif
c
c     ******************************************************************
c
c     Conditional definitions
c
#     ifdef _SIP_1_
#     define _SIP_
#     endif
c
#     ifdef _SIP_2_
#     define _SIP_
#     endif


#     ifdef _SCALAR1_QUICK_
#     define _ANY_QUICK_
#     endif
#     ifdef _SCALAR2_QUICK_
#     define _ANY_QUICK_
#     endif
#     ifndef _CENTRALTOQUCIK_
#     ifndef _CENTRAL_
#     define _ANY_QUICK_
#     endif
#     endif

#     ifdef _DES_
#     define _TRANSPORT_EQUATION_
#     endif 
#     ifdef _SCALAR1_
#     define _TRANSPORT_EQUATION_
#     endif 
#     ifdef _SCALAR2_
#     define _TRANSPORT_EQUATION_
#     endif 

c
c     ******************************************************************
